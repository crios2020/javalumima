-- Consultas de prueba
show tables;
select version();