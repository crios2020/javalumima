package ar.com.eduit.curso.java.test;
import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import java.util.List;
public class TestRepositories {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(new Connector());
        
        Curso curso=new Curso(".NET", "Sanchez", Dia.lunes, Turno.mañana);
        cr.save(curso);
        System.out.println(curso);
        
        cr.remove(cr.getById(7));
        
        curso=cr.getById(8);
        if(curso!=null){
            curso.setTurno(Turno.tarde);
            cr.update(curso);
        }
        //System.out.println(curso);
        
        
        System.out.println("**************************************************");
        List<Curso> list=cr.getAll();
        for(int a=0;a<list.size();a++) System.out.println(list.get(a));
        
        
        System.out.println("**************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(new Connector());
        
        Alumno alumno=new Alumno("Ariel","Molina",23,cr.getById(10));
        ar.save(alumno);
        System.out.println(alumno);
        
        System.out.println("**************************************************");
        
        ar.remove(ar.getById(4));
        
        alumno = ar.getById(6);
        if(alumno!=null){
            alumno.setCurso(cr.getById(1));
            ar.update(alumno);
        }
        
        List<Alumno>list2=ar.getAll();
        for(int a=0;a<list2.size();a++) System.out.println(list2.get(a));
        
        
        
    }
}