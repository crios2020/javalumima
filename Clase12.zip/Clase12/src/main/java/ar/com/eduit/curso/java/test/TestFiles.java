package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import ar.com.eduit.curso.java.utils.files.FileText;
import ar.com.eduit.curso.java.utils.files.I_File;
import java.util.ArrayList;
import java.util.List;

public class TestFiles {
    public static void main(String[] args) {
        String file="texto.txt";
        I_File fileText=new FileText(file);
        fileText.setText("Curso de Java.\n");
        fileText.setText("Hoy es miércoles\n");
        fileText.appendText("Primavera.\n");
        fileText.appendText("Verano.\n");
        fileText.appendText("Otoño.\n");
        fileText.appendText("Invierno.\n");
        fileText.addLine("Lunes.");
        fileText.addLine("Martes.");
        fileText.addLine("Miércoles.");
        fileText.addLine("Jueves.");
        fileText.addLine("Viernes.");
        
        List<String> list=new ArrayList();
        CursoRepository cr=new CursoRepository(new Connector());
        cr.getAll().forEach(c->list.add(c.getTitulo()));
        fileText.addLines(list);
        
        //System.out.println(fileText.getText());
        fileText.print();
        
        // FAlta STringBuffer
        
    }
}