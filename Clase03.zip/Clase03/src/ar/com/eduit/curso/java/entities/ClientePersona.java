package ar.com.eduit.curso.java.entities;
public class ClientePersona {
    private int nro;
    private String nombre;
    private String apellido;
    private Cuenta cuenta;
    //Celular celular;

    //El cliente nace con una cuenta y es unica de el
       public ClientePersona(int nro, String nombre, String apellido, int nroCuenta, String moneda) {
        this.nro = nro;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cuenta = new Cuenta(nroCuenta, moneda);
    }
    
    /*
    //El cliente nace con una cuenta y esta cuenta puede ser compartida
   public ClientePersona(int nro, String nombre, String apellido, Cuenta cuenta) {
        this.nro = nro;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cuenta = cuenta;
    }
    */
    
    /*
    //El cliente puede existir sin una cuenta
    public ClientePersona(int nro, String nombre, String apellido) {
        this.nro = nro;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    */
    
    /*
    //El cliente puede cambiar de cuenta
    public void setCuenta(Cuenta cuenta){
        this.cuenta=cuenta;
    }
    */
    
    /*
    //La persona tiene un celular (el celular es propio y lo puede cambiar)
    public void setCelular(Celular celular){
        celular=celular;
    }
    
    //La persona usa una computadora del aula
    public void usarComputadora(Computadora computadora){
        System.out.println("usando computadora: "+computadora);
    }
    */

    @Override
    public String toString() {
        return "ClientePersona{" + "nro=" + nro + ", nombre=" + nombre + ", apellido=" + apellido + '}';
    }

    public int getNro() {
        return nro;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }
  
}