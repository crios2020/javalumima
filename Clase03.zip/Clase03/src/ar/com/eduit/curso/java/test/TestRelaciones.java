package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;
import java.util.ArrayList;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("-- Test Relaciones --");
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(50000);
        cuenta1.depositar(70000);
        cuenta1.debitar(15000);
        System.out.println(cuenta1);
        
        System.out.println("-- cuenta2 --");
        Cuenta cuenta2=new Cuenta(2,"arg$");
        cuenta2.depositar(40000);
        cuenta2.debitar(10000);
        cuenta2.debitar(35000);
        System.out.println(cuenta2);
        
        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1 = new ClientePersona(1,"Ana","Garcia",10,"arg$");
        clientePersona1.getCuenta().depositar(30000);
        
        Cuenta cuentaCliente1=clientePersona1.getCuenta();
        cuentaCliente1.depositar(20000);
        cuentaCliente1.debitar(5000);
        
        System.out.println(clientePersona1);
        System.out.println(clientePersona1.getCuenta());
        
        System.out.println("-- clientePersona2 --");
        ClientePersona clientePersona2 = new ClientePersona(2,"Juan","Perez",11,"arg$");
        
        
        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1, "Todo Limpio SRL", "Lima 222");

        ArrayList<Cuenta> cuentas=clienteEmpresa1.getCuentas();
        
        cuentas.add(new Cuenta(20,"arg$"));         // 0
        cuentas.add(new Cuenta(21,"Reales"));       // 1 
        cuentas.add(new Cuenta(22,"U$S"));          // 2
        cuentas.add(cuenta1);                       // 3 
        cuentas.add(cuenta2);                       // 4
        
        cuentas.get(0).depositar(240000);
        cuentas.get(0).debitar(30000);
        cuentas.get(1).depositar(20000);
        cuentas.get(2).depositar(12000);
        
        System.out.println(clienteEmpresa1);
        for(int a=0;a<cuentas.size();a++) System.out.println(cuentas.get(a));
        
    }
}