package clase08.collecciones;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.Vector;

public class Clase08 {
    public static void main(String[] args) {
        
        //Vectores o Arrays
        Auto autos[]=new Auto[4];
        
        autos[0]=new Auto("Fiat","Uno","Blanco");
        autos[1]=new Auto("Renault","Kango","Bordo");
        autos[2]=new Auto("Peugeot","208","Negro");
        autos[3]=new Auto("Ford","Ka","Gris");
        
        //recorrido por indices
        //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
        
        //Estructura foreach        //jdk 5 o sup
        //Recorrido foreach
        for(Auto a:autos)    System.out.println(a);
        
        //Interface List
        List lista=new ArrayList();
        //List lista=new LinkedList();
        //List lista=new Vector();
        
        lista.add(new Auto("Citroen","C4","Azul"));     //0
        lista.add(new Auto("Fiat","Idea","Rojo"));      //1
        lista.add("Hola");                              //2
        lista.add(22);                                  //3
        lista.add(true);                                //4
        lista.remove(3);
        lista.add(1, "Java");
        //lista.remove("Hola");
        
        System.out.println("******************************************");
        //recorrido por indices
        //for(int a=0;a<lista.size();a++) System.out.println(lista.get(a));
        
        //recorrido foreach
        //for(Object o:lista) System.out.println(o);
        
        //metodo foreach    jdk 8
        //lista.forEach(o->System.out.println(o));
        //lista.forEach(o->{
        //    System.out.println(o);
        //});
        lista.forEach(System.out::println);
        
        System.out.println(System.getProperty("java.version"));
        
        //Uso de Generics <>  JDK 5
        List<Auto> lista2=new ArrayList();
        lista2.add(new Auto("Peugeot","306","Gris"));
        lista2.add(new Auto("Dodge","RAM","Negro"));
        //lista2.add(33);
        
        Auto auto1=(Auto)lista.get(0);
        Auto auto2=lista2.get(0);
        
        // copiar los autos del vector autos a lista2
        for(Auto a:autos) lista2.add(a);
        
        // copiar los autos de lista a lista2
        lista.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });
        
        System.out.println("****************************************");
        lista2.forEach(System.out::println);
        
        //Interface SET
        
        Set<String> setString;
        
        // Implementación HashSet:  es la más veloz, y no garantiza el orden de los elementos.
        //setString=new HashSet();
        
        // Implementación LinkedHashSet: almacena elementos en una lista enlazada por orden de
        //          ingreso,
        //setString=new LinkedHashSet();
        
        // Implementación TreeSet: almacena elementos en un arbol por orden natural
        setString=new TreeSet();
        
        
        setString.add("lunes");
        setString.add("martes");
        setString.add("martes");
        setString.add("lunes");
        setString.add("miércoles");
        setString.add("jueves");
        setString.add("jueves");
        setString.add("viernes");
        setString.add("sábado");
        setString.add("domingo");
        
        System.out.println("*************************************************");
        setString.forEach(System.out::println);
        
        
        Set<Integer>setInt=new TreeSet();
        setInt.add(4);
        setInt.add(2);
        System.out.println("*************************************************");
        setInt.forEach(System.out::println);
        
        Set<Auto>setAutos;
        //setAutos=new LinkedHashSet();
        setAutos=new TreeSet();
        setAutos.addAll(lista2);
        setAutos.add(new Auto("Fiat","Idea","Rojo"));
        setAutos.add(auto1);
        setAutos.add(auto2);
        
        System.out.println("*************************************************");
        setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));
        System.out.println("*************************************************");
        System.out.println(auto1+"\t"+auto1.hashCode());
        
        // Interface Queue Colas
        Queue<Auto>colaAutos=new ArrayDeque();
        colaAutos.offer(auto2); 
        // .offer() encola un elemento.
        colaAutos.addAll(lista2);
        
        System.out.println("*************************************************");
        colaAutos.forEach(System.out::println);
        System.out.println("Longitud de cola:"+colaAutos.size());
        while(!colaAutos.isEmpty()){
            System.out.println(colaAutos.poll());
            // .poll() desencola un elemento
        }
        System.out.println("Longitud de cola:"+colaAutos.size());
        
        //Clase Stack Pilas
        Stack<Auto>pilaAutos=new Stack();
        pilaAutos.push(auto1);
        //.push() apila un elemento
        pilaAutos.addAll(lista2);
        System.out.println("*************************************************");
        pilaAutos.forEach(System.out::println);
        System.out.println("Longitud de pila:"+pilaAutos.size());
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
        }
        System.out.println("Longitud de pila:"+pilaAutos.size());
    }
}