package ar.com.eduit.curso.java.connectors;
import java.sql.Connection;
import java.sql.DriverManager;
public class Connector {
    private String driver="com.mysql.cj.jdbc.Driver";
    private String vendor="mysql";
    private String server="localhost";
    //private String server="sql10.freemysqlhosting.net";
    private String port="3306";
    private String db="colegio";
    //private String db="sql10356467";
    private String params="?serverTimezone=UTC";
    private String user="root";
    //private String user="sql10356467";
    private String pass="";
    private String url="jdbc:"+vendor+"://"+server+":"+port+"/"+db+params;
    private Connection conn=null;
    public Connector() {
    }
    public Connection getConnection(){
        try {
            Class.forName(driver);
            conn=DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}