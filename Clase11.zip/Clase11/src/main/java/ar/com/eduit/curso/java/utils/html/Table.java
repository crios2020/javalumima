package ar.com.eduit.curso.java.utils.html;
import java.lang.reflect.Field;
import java.util.List;
public class Table<E>{
    public String getTable(List<E> list){
        if(list==null || list.isEmpty()) return "";
        String table="<table>\n";
        
        E e=list.get(0);
        Field[] campos=e.getClass().getDeclaredFields();
        
        table+="<tr>";
        for(Field f:campos) table+="<th>"+f.getName()+"</th>";
        table+="</tr>\n";
        
        for(E r:list){
            table+="<tr>";
            for(Field f:campos){
                table+="<td>";
                String metodo="get"
                        +f.getName().substring(0,1).toUpperCase()
                        +f.getName().substring(1);
                //table+=metodo;
                try{
                    table+=r.getClass().getDeclaredMethod(metodo, null).invoke(r, null);
                }catch(Exception ex){}
                table+="</td>";
            } 
            table+="</tr>\n";
        }
        
        table+="</table>";
        return table;
    }
    
    public String getTable(List<E> list,String pageDelete){
        if(list==null || list.isEmpty()) return "";
        String table="<table>\n";
        
        E e=list.get(0);
        Field[] campos=e.getClass().getDeclaredFields();
        
        table+="<tr>";
        for(Field f:campos) table+="<th>"+f.getName()+"</th>";
        table+="<th>borrar</th>";
        table+="</tr>\n";
        
        for(E r:list){
            table+="<tr>";
            for(Field f:campos){
                table+="<td>";
                String metodo="get"
                        +f.getName().substring(0,1).toUpperCase()
                        +f.getName().substring(1);
                //table+=metodo;
                try{
                    table+=r.getClass().getDeclaredMethod(metodo, null).invoke(r, null);
                }catch(Exception ex){}
                table+="</td>";
            }
            try{
            String id=r.getClass().getDeclaredMethod("getId", null).invoke(r, null).toString();
                table+="<td><a href='"+pageDelete+"?id="+id+"'>borrar</a></td>";
            }catch(Exception ex){}
            table+="</tr>\n";
        }
        
        table+="</table>";
        return table;
    }
}