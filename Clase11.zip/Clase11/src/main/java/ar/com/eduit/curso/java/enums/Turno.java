package ar.com.eduit.curso.java.enums;
public enum Turno { mañana,tarde,noche }