package clase01;

import java.util.Date;
import javax.swing.JOptionPane;

/**
 * Clase principal del proyecto Clase 01
 * @author carlos
 */
public class Clase01 {
    /**
     * Punto de entrada del proyecto
     * @param args Argumentos que ingresan desde consola
     */
    public static void main(String[] args) {
        /*
        Curso: Java Standard Web Programming 8.X        
        Días:  Lunes y Miércoles 10:00 a 13:00 hs.
        Profe: Carlos Ríos      carlos.rios@educacionit.com
        
        Materiales: alumni.educacionit.com
        user: email
        pass: dni
           
        github: https://github.com/crios2020/javalumima
        
        software:    JDK(Oracle, OpenJDK, REDHAT, Eclipse)    y un IDE
        
        Versión de JDK 
        Usamos versiones LTS    (Long Term Support) 8 años
     
        IDE: Netbeans 12.x, Eclipse, IntelliJ
        
        */
        
        //Comentario de una sola linea
        /* Bloque de comentarios */
        
        /**
         * Comentario Java DOC.
         * Debe colocarse delante de la declaración de métodos o clases.
         * Es accesible desde fuera del .class
         */
        
        // Tipo de datos primitivos
        
        // Tipo de datos enteros
        
        
        // Tipo de datos boolean        1 byte
        boolean bo=true;
        System.out.println(bo);
        bo=false;
        System.out.println(bo);
        
        /*
            0
            --------
        
        */
        
        
        // Tipo de datos byte           1 byte
        byte by=100;
        by=-120;
        System.out.println(by);
        
        // Tipo de datos short          2 bytes
        short sh=4000;
        System.out.println(sh);
        
        // Tipo de datos int            4 bytes
        int in=2000000000;
        System.out.println(in);
        
        // Tipo de datos long           8 bytes
        long lo=3000000000L;
        System.out.println(lo);
        
        // Tipo de datos char 2 bytes
        char ch=65;
        ch='c';
        ch-=32;
        System.out.println(ch);
        
        // Tipo de datos de punto flotante
        // Tipo de datos float 32 bits
        float fl=-4.87f;
        System.out.println(fl);
        
        // Tipo de datos double 64 bits
        double dl=-4.87;
        System.out.println(dl);
        
        fl=10;
        dl=10;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        fl=100;
        dl=100;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        String st="Hola";              //java.lang
        
        //JDK 11            Hola        4 bytes     byte[]
        //JDK  8            Hola        8 bytes     char[]
        
        System.out.println(st);
        
        Date da=new Date();
        
        // tipo de datos var JDK 9 o superior
        var var1=12;                //int
        var1=34;
        var var2=12L;               //long
        var2=34;
        var var3=23.34;             //double
        var var4=23.34d;            //double
        var var5=23.34f;            //float
        var var6=false;             //boolean
        var var7='a';               //char
        var var8="Hola";            //String
        
        //JOptionPane.showMessageDialog(null, "Hola a todos!");
        
        String cadena="Cadena de texto!";
        System.out.println(cadena);
        
        //Recorrer el vector de un String manualmente
        for(int a=0; a<cadena.length(); a++){
            System.out.print(cadena.charAt(a));
        }
        System.out.println();
        
        //Imprimir cadena todo en mayuscula
        for(int a=0; a<cadena.length(); a++){
            char car=cadena.charAt(a);
            if(car>=97 && car<=122) car-=32; 
            System.out.print(car);
        }
        System.out.println();
        System.out.println(cadena.toUpperCase());
        System.out.println(cadena.toLowerCase());
        
    } 
}