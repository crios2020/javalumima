package clase08.collecciones;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
public class Clase09Stream {
    public static void main(String[] args) {
        List<Auto>lista=new ArrayList();
        lista.add(new Auto("Fiat","Uno","Blanco"));
        lista.add(new Auto("Renault","Kango","Bordo"));
        lista.add(new Auto("Peugeot","208","Negro"));
        lista.add(new Auto("Ford","Ka","Gris"));
        lista.add(new Auto("Citroen","C4","Azul"));
        lista.add(new Auto("Fiat","Idea","Rojo"));
        lista.add(new Auto("Peugeot","306","Gris"));
        lista.add(new Auto("Dodge","RAM","Negro"));
        lista.add(new Auto("Fiat","Idea","Rojo"));

        
        //Api Stream JDK 8
        
        // select * from autos;
        System.out.println("*************************************************");
        //lista.forEach(System.out::println);
        lista.stream().forEach(System.out::println);
        
        
        // select * from autos where color='rojo';
        System.out.println("*************************************************");
        /*
        lista.forEach(auto->{
            if(auto.getColor().equals("Rojo")) System.out.println(auto);
        });
        */
        lista
                .stream()
                .filter(a->a.getColor().equalsIgnoreCase("rojo"))
                .forEach(System.out::println);
        
        //select * from autos where marca='Fiat' and modelo='Idea';
        System.out.println("*************************************************");
        lista
                .stream()
                .filter(a->a.getMarca().equals("Fiat")
                        && a.getModelo().equals("Idea"))
                .forEach(System.out::println);
                
        
        //select * from autos where marca like '%f%';
        System.out.println("*************************************************");
        lista
                .stream()
                .filter(a->a.getMarca().toLowerCase().contains("f"))
                .forEach(System.out::println);
        

        //select * from autos order by color,marca,modelo
        System.out.println("*************************************************");
        //lista
        //        .stream()
        //        .sorted()                       //ordenado por Comparable
        //        .forEach(System.out::println);
        lista
                .stream()
                .sorted(Comparator.comparing(Auto::getColor)
                        .thenComparing(Comparator.comparing(Auto::getMarca))
                        .thenComparing(Comparator.comparing(Auto::getModelo)))
                .forEach(System.out::println);
        
    }
}