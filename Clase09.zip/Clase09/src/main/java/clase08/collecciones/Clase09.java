package clase08.collecciones;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
public class Clase09 {
    public static void main(String[] args) {
        Map<String,String> map;
        
        //Implementación HashMap: es la más veloz y es desordenada
        //map=new HashMap();
        
        //Implementación LinkedHashMap: almacena en una lista enlazada por orden de ingreso
        //map=new LinkedHashMap();
        
        //Implementación TreeMap: almacena en una arbo por orden natural (Comparable)
        map=new TreeMap();
        
        //Implementación Hashtable: se comporta igual que HashMap, soporta multihilo, es legacy
        //map=new Hashtable();
        
        
        map.put("lu", "lunes");
        map.put("xx", "lunes");
        map.put("ma", "martes");
        map.put("mi", "miércoles");
        map.put("ju", "jueves");
        map.put("vi", "viernes");
        map.put("sa", "sábado");
        map.put("do", "domingo");
        
        //obtener un valor del mapa
        //System.out.println(map.get("ju"));
        
        //recorrido del mapa
        //map.keySet().forEach(k->System.out.println(k+": "+map.get(k)));
        map.forEach((k,v)->System.out.println(k+": "+v));
        
        
    }
}