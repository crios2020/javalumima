package ar.com.eduit.curso.java.test;

import java.time.LocalTime;

public class TestString {
    public static void main(String[] args) {
        
        
        String texto="";
        /*
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="h";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="o";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="l";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="a";
        System.out.println(texto+"\t"+texto.hashCode());
        */
        
        StringBuilder sb=new StringBuilder();      // JDK 5    MonoHilo
        StringBuffer  sf=new StringBuffer();       // JDK 1    Multihilos
        
        System.out.println(LocalTime.now());
        for(int a=0;a<2000000;a++){
            texto+="x";
            //sb.append("x");
        }
        System.out.println(LocalTime.now());
        //System.out.println(sb.toString());
        
    }
}