package ar.com.eduit.curso.java.repositories.jdbc;
import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class AlumnoRepository implements I_AlumnoRepository{
    private Connector connector;

    public AlumnoRepository(Connector connector) {
        this.connector = connector;
    }
    
    @Override
    public void save(Alumno alumno) {
        if(alumno==null) return;
        try(PreparedStatement ps=connector.getConnection().prepareStatement(
                "insert into alumnos (nombre,apellido,edad,idCurso) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, alumno.getNombre());
            ps.setString(2, alumno.getApellido());
            ps.setInt(3, alumno.getEdad());
            ps.setInt(4, alumno.getCurso().getId());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) alumno.setId(rs.getInt(1));
        } catch (Exception e) {
            e.printStackTrace();
        }  
    }

    @Override
    public void remove(Alumno alumno) {
        if(alumno==null) return;   
        try (PreparedStatement ps=connector.getConnection().prepareStatement(
                "delete from alumnos where id=?")) {
            ps.setInt(1, alumno.getId());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Alumno alumno) {
        if(alumno==null) return;
        try (PreparedStatement ps=connector.getConnection().prepareStatement(
                "update alumnos set nombre=?,apellido=?,edad=?,idCurso=? where id=?")){
           ps.setString(1, alumno.getNombre());
           ps.setString(2, alumno.getApellido());
           ps.setInt(3, alumno.getEdad());
           ps.setInt(4, alumno.getCurso().getId());
           ps.setInt(5, alumno.getId());
           ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    @Override
    public Alumno getById(int id) {
        Alumno alumno=null;
        try (ResultSet rs=connector.getConnection().createStatement().executeQuery(
                "select a.id,nombre,apellido,edad,idCurso,c.id,titulo,profesor,dia,turno "
                        + "from alumnos a join cursos c on a.idCurso=c.id "
                        + "where a.id="+id)){
            if(rs.next()){
                alumno=new Alumno(
                        rs.getInt("a.id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("edad"),
                        new Curso(
                                rs.getInt("c.id"),
                                rs.getString("titulo"),
                                rs.getString("profesor"),
                                Dia.valueOf(rs.getString("dia")),
                                Turno.valueOf(rs.getString("turno"))
                        )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return alumno;
    }
    */

    @Override
    public List<Alumno> getAll() {
       List<Alumno>list=new ArrayList();
        try (ResultSet rs=connector.getConnection().createStatement().executeQuery(
                "select a.id,nombre,apellido,edad,idCurso,c.id,titulo,profesor,dia,turno "
                        + "from alumnos a join cursos c on a.idCurso=c.id")){
            while(rs.next()){
                list.add(new Alumno(
                        rs.getInt("a.id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("edad"),
                        new Curso(
                                rs.getInt("c.id"),
                                rs.getString("titulo"),
                                rs.getString("profesor"),
                                Dia.valueOf(rs.getString("dia")),
                                Turno.valueOf(rs.getString("turno"))
                        )
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
       return list;
    }

    /*
    @Override
    public List<Alumno> getLikeApellido(String apellido) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    */

    /*
    @Override
    public List<Alumno> getByCurso(Curso curso) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    */
    
}