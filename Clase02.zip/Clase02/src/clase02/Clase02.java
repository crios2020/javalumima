package clase02;

import javax.swing.JOptionPane;

public class Clase02 {
    public static void main(String[] args) {
        //punto de entrada al proyecto.
        //se pueden ejecutar las clases que tienen método main
        System.out.println("Clase01");
        
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();
        auto1.marca="Fiat";
        auto1.modelo="Palio";
        auto1.color="Rojo";
        auto1.acelerar();       //10
        auto1.acelerar();       //20
        auto1.acelerar();       //30
        auto1.frenar();         //20
        auto1.acelerar(25);     //45
        
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color
                            +" "+auto1.velocidad);
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Fiesta";
        auto2.color="Azul";
        for(int a=0;a<=65;a++) auto2.acelerar();
        
         System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color
                            +" "+auto2.velocidad);
                
        //Los atributos String se inicializan automaticamente en null
        //Los atributos Numericos se inicializan automaticamente en 0
        //Las variables deben ser inicializadas
        
        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Citroen", "C4", "Bordo");
        auto3.acelerar(34);
        auto3.imprimirVelocidad();
        
        System.out.println(auto3.getVelocidad());
        
        //JOptionPane.showMessageDialog(null, "velocidad: "+auto3.getVelocidad());
             
        //Método toString()
        System.out.println(auto3.toString());
        System.out.println(auto3);
        
        System.out.println("-- empleado1 --");
        Empleado empleado1=new Empleado(1, "Juan", "Segovia", 80000);
        //empleado1.sueldoBasico=8000000;
        empleado1.setSueldoBasico(800000000);
        System.out.println(empleado1);
        
        /*
        Modificadores de visibilidad de miembros de clases (Atributo o Método)
        
        Modificador         Alcance
        default(omitido)    solo son accesibles desde la misma clase y desde 
                            clases del mismo paquete
        
        public              es accesible desde la misma clase y cualquier clase
                            de cualquier paquete.
        
        private             solo es accesible desde la misma clase.
        
        protected           es accesible desde la misma clase o desde clases hijas
                            o desde clases del mismo clases
        
        
        */
        
    }
}