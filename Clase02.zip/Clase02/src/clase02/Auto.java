package clase02;

/*
Un archivo .java puede contenter clases enums interfaces
un solo miembro de archivo puede ser publico
El miembro publico puede ser accedido desde cualquier paquete
Los miembros no publicos solo son visibles desde el mismo paquete

Una clase en java es un objeto de la clase java.lang.Class

Atributos: los atributos son objetos de la clase java.lang.relect.Field

Métodos: los métodos son objetos de la clase java.lang.reflect.Method

Sobrecarga de métodos, cuando varios métodos tienen el mismo nombre, dentro
de una clase, lo que cambia es la firma de parametros.

Costructores: Tiene el mismo nombre, no tiene devolución de valor, Se ejecutan
al crear un objeto, pueden ser sobrecargados.
Si la clase no tiene constructores, java agrega uno vacio al compilar.
Los constructores en java son objetos de la clase java.lang.reflect.Constructor
*/

//declaración de clases
public class Auto { 
    // Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    //Métodos constructores
    /**
     * Método deprecado por considerase inseguro, por Carlos Ríos fecha 08/07/2020
     * usar en su reeemplazo Auto(String marca, String modelo, String color)
     * @deprecated
     */
    @Deprecated
    Auto() {} //Constructor Vacio
    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }
    
    // Métodos
    void acelerar() {                                   //acelerar
        //velocidad+=10; 
        //if (velocidad>100) velocidad=100;
        acelerar(10);
    }
    // Método sobrecargado
    void acelerar(int kilometros) {                     //acelerarInt
        velocidad+=kilometros;
        if (velocidad>100) velocidad=100;
    }
    void acelerar(int x, String valor){}                //acelerarIntString
    void acelerar(String valor, int x){}                //acelerarStringInt
    
    void frenar()   { velocidad-=10; }
    
    void imprimirVelocidad(){ 
        System.out.println(velocidad); 
    }
    
    int getVelocidad() {
        return velocidad;
    }
    
    @Override
    public String toString(){
        return marca+","+modelo+","+color+","+velocidad;
    }
    
}
class Moto{ String marca; String modelo; String color; int velocidad; void acelerar(){}}
class Bici{}
interface I_Vehiculo{}
interface I_Transporte{}
enum Dia{}
enum Mes{}


