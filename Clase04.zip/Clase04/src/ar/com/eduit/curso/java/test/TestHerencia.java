package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Empleado;
import ar.com.eduit.curso.java.entities.Persona;

public class TestHerencia {
    public static void main(String[] args) {
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(50000);
        cuenta1.depositar(70000);
        cuenta1.debitar(15000);
        System.out.println(cuenta1);
        
        System.out.println("-- cuenta2 --");
        Cuenta cuenta2=new Cuenta(2,"arg$");
        cuenta2.depositar(40000);
        cuenta2.debitar(10000);
        cuenta2.debitar(35000);
        System.out.println(cuenta2);
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Peña", 2485, "4", "e");
        System.out.println(dir1);
        
        System.out.println("-- dir --");
        Direccion dir2=new Direccion("Belgrano", 45, null, null, "Moron");
        System.out.println(dir2);
        
        /*
        //clase abstracta
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Daniela", "Leque", 27, dir2);
        System.out.println(persona1);
        persona1.saludar();
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Leandro","Mirelli",32, dir2);
        System.out.println(persona2);
        persona2.saludar();
        */
        
        System.out.println("-- empleado1 --");
        Empleado empleado1 = new Empleado(1, 70000, "Gabriela", "Guinso", 33, dir2);
        System.out.println(empleado1);
        empleado1.saludar();
        
        System.out.println("-- cliente1 --");
        Cliente cliente1 = new Cliente(1, cuenta2, "Luis", "Cetroni", 34, dir1);
        System.out.println(cliente1);
        cliente1.saludar();
        
        
        // analisis de objeto cliente1
        System.out.println(cliente1.getClass());
        System.out.println(cliente1.getClass().getName());
        System.out.println(cliente1.getClass().getSimpleName());
        System.out.println(cliente1.getClass().getSuperclass().getName());
        System.out.println(cliente1.getClass().getSuperclass().getSuperclass().getName());
        
        String st="texto";
        System.out.println(st.getClass().getName());
        System.out.println(st.getClass().getSuperclass().getName());
        
        System.out.println(
                cliente1
                        .getClass()
                        .getSuperclass()
                        .getSuperclass()
                        .getSuperclass()
        );
        
        //Polimorfismo
        Persona p1=new Empleado(2, 120000, "Laura", "Salas", 26, dir2);
        Persona p2=new Cliente(2,cuenta1,"David","Godoy",30,dir1);
        
        p1.saludar();
        p2.saludar();
        
        //Empleado e1=(Empleado)p1;
        
        Empleado e1;        
        //if(p1 instanceof Empleado) e1=(Empleado)p1;
        if(p1.getClass().getSimpleName().equals("Empleado")) e1=(Empleado)p1;
        
        //Operador Ternario ?
        e1=(p1 instanceof Empleado)?(Empleado)p1:null;

       
    }
}