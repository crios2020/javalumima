package ar.com.eduit.curso.java.test;
public class MetodosEstaticos {
    public static void main(String[] args) {
        Auto.acelerar(30);
        Auto auto1=new Auto("Fiat","Uno","Blanco");
        Auto.acelerar(15);
        System.out.println(auto1);
        System.out.println(Auto.velocidad);
        
        Auto auto2=new Auto("Renault","12","Azul");
        Auto.acelerar(20);
        System.out.println(auto2);
        System.out.println(Auto.velocidad);
        

    }
}
class Auto{
    String marca;
    String modelo;
    String color;
    static int velocidad;

    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
     public static void acelerar(int kms) {
         velocidad+=kms;
     }

    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", modelo=" + modelo + ", color=" + color + '}';
    }

    public static int getVelocidad() {
        return velocidad;
    }
     
     
}