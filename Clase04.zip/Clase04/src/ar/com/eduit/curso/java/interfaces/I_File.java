package ar.com.eduit.curso.java.interfaces;
public interface I_File {
    /*
        - Todos los miembros de una interface son publicos.
        - Una interface solo tiene métodos abstractos y constantes, 
            no tiene atributos ni constructores.
        - Una clase puede implementar todas las interfaces que necesite.
        - La JavaDOC es heredada.
    */
    
    /**
     * Este método escribe el archivo
     * @param text texto a escribir en un archivo
     */
    void setText(String text);
    String getText();
    
    /*
    Java 8
    métodos default: es un método que tiene cuerpo (código), y como una clase puede 
    implementar muchas interfaces, se produce una especia de herencia multiple.
    */
    default void info(){
        System.out.println("Interface I_Archivo");
    }
}