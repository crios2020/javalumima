package ar.com.eduit.curso.java.utils;
import ar.com.eduit.curso.java.interfaces.I_File;
public class FileBinary implements I_File {
    private String file;

    public FileBinary() {
        file="datos.dat";
    }

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo archivo binario");
    }

    @Override
    public String getText() {
        return "contenido de archivo binario";
    }

}