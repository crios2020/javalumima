package ar.com.eduit.curso.java.test;
import ar.com.eduit.curso.java.interfaces.I_File;
import ar.com.eduit.curso.java.utils.FileBinary;
import ar.com.eduit.curso.java.utils.FileText;
import java.util.Scanner;
public class TestInterfaces {
    public static void main(String[] args) throws Exception {
        
        I_File file=null;
        
        //file=new FileText();
        //file=new FileBinary();
        
        System.out.println("Ingrese 'FileText' - 'FileBinary'");
        String in=new Scanner(System.in).next();
        
        /*
        if(in.equals("FileText"))   file=new FileText();
        if(in.equals("FileBinary")) file=new FileBinary();
        */
        
        file=(I_File)Class.forName("ar.com.eduit.curso.java.utils."+in).newInstance();
        
        // app
        file.setText("hola");
        System.out.println(file.getText());
        file.info();
        
    }
}