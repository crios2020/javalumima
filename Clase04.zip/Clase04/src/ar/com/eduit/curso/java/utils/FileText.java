package ar.com.eduit.curso.java.utils;
import ar.com.eduit.curso.java.interfaces.I_File;
public class FileText implements I_File{

    private String file;

    public FileText() {
        file="c:/texto.txt";
    }
    
    
    @Override
    public void setText(String text) {
        System.out.println("Escribiendo archivo de texto!");
    }

    @Override
    public String getText() {
        return "contenido de archivo texto";
    }
    
}