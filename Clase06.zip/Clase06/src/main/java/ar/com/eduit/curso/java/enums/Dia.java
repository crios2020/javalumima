package ar.com.eduit.curso.java.enums;
public enum Dia { lunes,martes,miercoles,jueves,viernes }