package clase05;
public class GeneradorDeExceptions {
    public static void generar(){
        //ArrayIndexOutOfBoundsException
        int[] vector=new int[5];
        vector[10]=20;
    }
    public static void generar(boolean x){
        //ArithmeticException
        if(x) System.out.println(10/0);
    }
    public static void generar(String nro){         
        //NumberFormatException
        int numero=Integer.parseInt(nro);
    }
    public static void generar(String texto,int index){     //null,10
        //NullPointerException  -   StringIndexOutOfBoundsException
        //if(texto==null || texto.length()<0 || texto.length()<=index) return;
        System.out.println(texto.charAt(index));
    }
}