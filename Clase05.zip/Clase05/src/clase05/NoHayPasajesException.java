package clase05;
public class NoHayPasajesException extends Exception {
    private String vuelo;
    private int cantidadPasajes;
    private int cantidadPasajesSolicitados;

    public NoHayPasajesException(String vuelo, int cantidadPasajes, int cantidadPasajesSolicitados) {
        this.vuelo = vuelo;
        this.cantidadPasajes = cantidadPasajes;
        this.cantidadPasajesSolicitados = cantidadPasajesSolicitados;
    }

    @Override
    public String toString() {
        return "El vuelo" + vuelo + ", no tiene " + cantidadPasajesSolicitados + " pasajes, solo tiene " + cantidadPasajes + " pasajes";
    }

    @Override
    public String getMessage() {
        return this.toString();
    }

    public String getVuelo() {
        return vuelo;
    }

    public int getCantidadPasajes() {
        return cantidadPasajes;
    }

    public int getCantidadPasajesSolicitados() {
        return cantidadPasajesSolicitados;
    }
    
}