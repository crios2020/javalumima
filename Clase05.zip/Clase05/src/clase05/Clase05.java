package clase05;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Clase05 {
    public static void main(String[] args) {
        // Clase 05 Manejo de Exceptions
        //System.exit(1);
        //System.out.println(10/0);
        //System.out.println("Esta linea de código no se ejecuta!");
        
        /*
        // Estructura Try Catch Finally
        
        try{                        // obligatorio
            //Colocar aca las sentencias que pueden lanzar exception.
            //Estas sentencias, tienen más consumo de hardware.
            //Si se ejecutan normalmente, el bloque termina, y salta a finally.
            //Si alguna sentencia, lanza exception(error), el control de 
            //ejecución salta a catch (No se detiene el programa).
        }catch(Exception e){        // obligatorio
            //Este bloque se ejecuta en caso de exception (en el bloque try).
            //Se recibe como parametro un objeto de Exception.
            //El bloque termina y salta el control a finally
        }finally{                   // opcional
            //Este bloque se ejecuta siempre. Ocurra una Exception o no.
            //Los objetos o variables declarados en bloque try o en catch
            //estan fuera de Scope
        }
        // Estas lineas támbien se ejecutan.
        // El programa termina normalmente.
    
        */
        
        /*
        try{
            System.out.println(10/0);
            System.out.println("Esta sentencia no se ejecuta!!");
        }catch(Exception e){
            System.out.println("Ocurrio un error!");
            //System.out.println(e);
            //System.out.println(e.getMessage());
            e.printStackTrace();
            //System.err.println(e);
        }finally{
            System.out.println("El programa termina normalmente!");
        }
        System.out.println("Fin del programa");
        */
        
        //Unchecked Exception
        //int numero=Integer.parseInt("22x");
        //System.out.println(10/0);
        
        //Checked Exception
        //try{
        //    FileReader in=new FileReader(new File("c:/texto.txt"));
        //}catch(Exception e){}
        
        /*
        try {
            //GeneradorDeExceptions.generar();
            //GeneradorDeExceptions.generar(true);
            //GeneradorDeExceptions.generar("22x");
            //GeneradorDeExceptions.generar(null, 10);
            //GeneradorDeExceptions.generar("Hola", 10);
            System.out.println("Esta sentencia no se ejecuta!");
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Fin del programa");
        */
        
        
        //Captura personalizada de exceptions
        try{
            //GeneradorDeExceptions.generar();
            //GeneradorDeExceptions.generar(true);
            //GeneradorDeExceptions.generar("22x");
            //GeneradorDeExceptions.generar(null, 20);
            //GeneradorDeExceptions.generar("hola", 20);
            //FileReader in=new FileReader(new File("c:/texto.txt"));
        //}catch(ArrayIndexOutOfBoundsException e)    { System.out.println("Indice fuera de rango");
        }catch(ArithmeticException e)               { System.out.println("División / 0");
        }catch(NumberFormatException e)             { System.out.println("Formato de número incorrecto");
        }catch(NullPointerException e)              { System.out.println("Puntero Nulo");
        //}catch(StringIndexOutOfBoundsException e)   { System.out.println("Indice fuera de rango");
        //}catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) {
            //multicatch
        //    System.out.println("Indice fuera de rango");
        }catch(IndexOutOfBoundsException e)         { System.out.println("Indice fuera de rango");
        //}catch(FileNotFoundException e)             { System.out.println("No se encontro el archivo!");
        //}catch(IOException e)                       { System.out.println("Error IO");
        }catch(Exception e)                         { System.out.println("Ocurrio un error no esperado");
        }
        
        /*
            uso de Exceptions para manejar reglas de negocio
        */
        
        //Venta de pasajes
        Vuelo v1=new Vuelo("AER1234",100);
        Vuelo v2=new Vuelo("LAT1111",100);
        
        
        try {
            v1.venderPasajes(60);
            v2.venderPasajes(20);
            v1.venderPasajes(20);
            v2.venderPasajes(20);       
            v1.venderPasajes(40);       //Lanzar Exception
            v2.venderPasajes(10);       //Esta venta no se realiza.
        } catch (NoHayPasajesException ex) {
            System.out.println(ex);
        }
        
        /*
        //Código no correcto
        try{
            FileReader in=new FileReader("c:/texto.txt");
            try {

                System.out.println(in.read());
                in.close();
            } catch (Exception e) {
                e.printStackTrace();
            }finally{
                if(in!=null){
                    in.close();
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        */
        
        
        //Interface AutoCloseable JDK7
        //Try With Resources JDK 7
        /*
        try (FileReader in=new FileReader("c:/texto.txt");) {
            System.out.println(in.read());
        } catch (Exception e) {
            e.printStackTrace();
        }
        */
        System.out.println("*************************************************");
        try (Lector lector=new Lector("texto.txt")){
            //if(true) throw new Exception();
            System.out.println(lector.leer());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}