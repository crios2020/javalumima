package clase05;
import java.io.Closeable;
import java.io.IOException;
public class Lector implements Closeable{
    private String file;

    public Lector(String file) {
        this.file = file;
    }
    
    public String leer(){
        return "Contenido de Archivo";
    }
    
    @Override
    public void close() throws IOException {
        System.out.println("Se cerro el archivo!");
    }
    
}