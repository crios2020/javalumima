package clase05;
public class Vuelo {
    private String nombre;
    private int cantidadPasajes;

    public Vuelo(String nombre, int cantidadPasajes) {
        this.nombre = nombre;
        this.cantidadPasajes = cantidadPasajes;
    }
    
    public synchronized void venderPasajes(int cantidadPasajesSolicitados) throws NoHayPasajesException{
        if(cantidadPasajesSolicitados>cantidadPasajes)
            throw new NoHayPasajesException(nombre, cantidadPasajes, cantidadPasajesSolicitados);
        cantidadPasajes-=cantidadPasajesSolicitados;
    }

    @Override
    public String toString() {
        return "Vuelo{" + "nombre=" + nombre + ", cantidadPasajes=" + cantidadPasajes + '}';
    }

    public int getCantidadPasajes() {
        return cantidadPasajes;
    }

    public String getNombre() {
        return nombre;
    }
    
}